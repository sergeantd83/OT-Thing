To install binary release:

- Hold down Boot button on OTGW32, plug in to PC, release Boot button
- Double click on flash.bat (Windows) or flash.sh (Linux)
- Press Reset on OTGW32, status LED should flash
- Configure Wi-Fi by connecting to SSID "OT Thing" pw "12345678" then visit http://4.3.2.1/
